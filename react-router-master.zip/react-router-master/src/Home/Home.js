import React, { Component } from 'react';

class Home extends Component {
  render() {
    return (
      <div className="page">
        <h1>React Medellín: React Router</h1>
      </div>
    );
  }
}

export default Home;
